/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Copyright(c) 2020 - 2023 Allwinner Technology Co.,Ltd. All rights reserved. */
/*
 * A V4L2 driver for nvp6324 cameras and AHD Coax protocol.
 *
 * Copyright (c) 2017 by Allwinnertech Co., Ltd.  http://www.allwinnertech.com
 *
 * Authors:  Li Huiyu <lihuiyu@allwinnertech.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 */
#include "../../../utility/vin_log.h"
#include <linux/string.h>
#include <linux/delay.h>
#include "jaguar1_common2.h"
#include "jaguar1_motion2.h"

/**************************************************************************************
 * @desc
 * 	JAGUAR1's
 *
 * @param_in		(motion_mode *)p_param->channel                  FW Update channel
 *
 * @return   	void  		       								 None
 *
 * ioctl : IOC_VDEC_MOTION_SET
 ***************************************************************************************/

void motion_detection_get2(motion_mode *motion_set)
{

	unsigned char ReadVal = 0;
	unsigned char ch_mask = 1;
	unsigned char ch = motion_set->ch;
	unsigned char ret = 0;

	ch_mask = ch_mask<<ch;

	gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0xFF, 0x00);
	ReadVal = gpio_i2c_read2(jaguar1_i2c_addr2[motion_set->devnum], 0xA1);

	ret = ReadVal&ch_mask;
	motion_set->set_val = ret;

}

void motion_onoff_set2(motion_mode *motion_set)
{
	gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0xFF, 0x04);

	if (motion_set->fmtdef == TVI_3M_18P2 || motion_set->fmtdef == TVI_5M_12_5P2 || motion_set->fmtdef == TVI_5M_12_5P2/* TVI_5M20P */) {
		gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x00 + (0x07 * motion_set->ch), 0x0C);
		gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x02 + (0x07 * motion_set->ch), 0x23);
		gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x28 + (0x06 * motion_set->ch), 0x11);

		if (motion_set->fmtdef == TVI_3M_18P2) {
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x29 + (0x06 * motion_set->ch), 0x78);
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x2A + (0x06 * motion_set->ch), 0x40);
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x2C + (0x06 * motion_set->ch), 0x72);
		} else if (motion_set->fmtdef == TVI_5M_12_5P2) {
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x29 + (0x06 * motion_set->ch), 0xA2);
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x2A + (0x06 * motion_set->ch), 0x51);
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x2C + (0x06 * motion_set->ch), 0x96);
		}

		gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x2B + (0x06 * motion_set->ch), 0x6);

		printk("[DRV_Motion_OnOff] ch(%d) fmtdef(%d)\n", motion_set->ch, motion_set->fmtdef);
	} else {
		gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x28 + (0x06 * motion_set->ch), 0x00);
	}

	if (motion_set->set_val < 0 || motion_set->set_val > 1) {
		printk("[DRV_Motion_OnOff]Error!! ch(%d) Setting Value Over:%x!! Only 0 or 1\n", motion_set->ch, motion_set->set_val);
		return;
	}

	switch (motion_set->set_val) {
	case FUNC_OFF2:
	gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], (0x00 + (0x07 * motion_set->ch)), 0x0D);
						gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x28 + (0x06 * motion_set->ch), 0x00);
						break;
	case FUNC_ON2:
	gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], (0x00 + (0x07 * motion_set->ch)), 0x0C);
					   break;
	}


}
void motion_pixel_all_onoff_set2(motion_mode *motion_set)
{
	int ii = 0;
	unsigned char addr = 0;

	gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0xFF, 0x04);
	if (motion_set->fmtdef == TVI_3M_18P2 || motion_set->fmtdef == TVI_5M_12_5P2 || motion_set->fmtdef == TVI_5M_12_5P2/* TVI_5M20P */) {
		gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x00 + (0x07 * motion_set->ch), 0x0C);
		gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x02 + (0x07 * motion_set->ch), 0x23);
		gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x28 + (0x06 * motion_set->ch), 0x11);

		if (motion_set->fmtdef == TVI_3M_18P2) {
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x29 + (0x06 * motion_set->ch), 0x78);
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x2A + (0x06 * motion_set->ch), 0x40);
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x2C + (0x06 * motion_set->ch), 0x72);
		} else if (motion_set->fmtdef == TVI_5M_12_5P2) {
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x29 + (0x06 * motion_set->ch), 0xA2);
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x2A + (0x06 * motion_set->ch), 0x51);
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x2C + (0x06 * motion_set->ch), 0x96);
		}

		gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x2B + (0x06 * motion_set->ch), 0x6);

		printk("[DRV_Motion_OnOff] ch(%d) fmtdef(%d)\n", motion_set->ch, motion_set->fmtdef);
	} else {
		gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x28 + (0x06 * motion_set->ch), 0x00);
	}

	for (ii = 0; ii < 24; ii++) {
		gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], (0x40 + (0x18 * motion_set->ch)) + ii, motion_set->set_val);
		addr = (0x40 + (0x18 * motion_set->ch)) + ii;
	}
}

void motion_pixel_onoff_set2(motion_mode *motion_set)
{
	unsigned char val = 0x80;
	unsigned char ReadVal;
	unsigned char on;

	unsigned char ch      = motion_set->ch;
	unsigned char SetPix  = motion_set->set_val/8;
	unsigned char SetVal  = motion_set->set_val%8;

	val = val >> SetVal;

	gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0xFF, 0x04);

	if (motion_set->fmtdef == TVI_3M_18P2 || motion_set->fmtdef == TVI_5M_12_5P2 || motion_set->fmtdef == TVI_5M_12_5P2/* TVI_5M20P */) {
		gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x00 + (0x07 * motion_set->ch), 0x0C);
		gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x02 + (0x07 * motion_set->ch), 0x23);
		gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x28 + (0x06 * motion_set->ch), 0x11);

		if (motion_set->fmtdef == TVI_3M_18P2) {
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x29 + (0x06 * motion_set->ch), 0x78);
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x2A + (0x06 * motion_set->ch), 0x40);
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x2C + (0x06 * motion_set->ch), 0x72);
		} else if (motion_set->fmtdef == TVI_5M_12_5P2) {
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x29 + (0x06 * motion_set->ch), 0xA2);
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x2A + (0x06 * motion_set->ch), 0x51);
			gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x2C + (0x06 * motion_set->ch), 0x96);
		}

		gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x2B + (0x06 * motion_set->ch), 0x6);

		printk("[DRV_Motion_OnOff] ch(%d) fmtdef(%d)\n", motion_set->ch, motion_set->fmtdef);
	} else {
		gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0x28 + (0x06 * motion_set->ch), 0x00);
	}

	ReadVal = gpio_i2c_read2(jaguar1_i2c_addr2[motion_set->devnum], (0x40 + (0x18 * ch)) + SetPix);
	on = val&ReadVal;
	if (on) {
		val = ~val;
		val = val&ReadVal;
	} else {
		val = val|ReadVal;
	}
	gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], (0x40 + (0x18 * ch)) + SetPix, val);
}

void motion_pixel_onoff_get2(motion_mode *motion_set)
{
	unsigned char val = 0x80;
	unsigned char ReadVal;
	unsigned char on;

	unsigned char Ch      = motion_set->ch;
	unsigned char SetPix  = motion_set->set_val/8;
	unsigned char SetVal  = motion_set->set_val%8;

	val = val >> SetVal;

	gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0xFF, 0x04);
	ReadVal = gpio_i2c_read2(jaguar1_i2c_addr2[motion_set->devnum], (0x40 + (0x18 * Ch)) + SetPix);

	on = val&ReadVal;

	if (on) {
		motion_set->set_val = 1;
	} else {
		motion_set->set_val = 0;
	}
}

void motion_tsen_set2(motion_mode *motion_set)
{
	unsigned char ch = motion_set->ch;
	unsigned char SetVal = motion_set->set_val;

	gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0xFF, 0x04);
	gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], (0x01 + (0x07 * ch)), SetVal);
	printk("[DRV_Motion]ch(%d), TSEN Val(%x)\n", ch, SetVal);
}

void motion_psen_set2(motion_mode *motion_set)
{
	unsigned char msb_mask = 0xf0;
	unsigned char lsb_mask = 0x07;
	unsigned char ch = motion_set->ch;
	unsigned char SetVal = motion_set->set_val;
	unsigned char ReadVal;

	gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], 0xFF, 0x04);
	ReadVal = gpio_i2c_read2(jaguar1_i2c_addr2[motion_set->devnum], (0x02 + (0x07 * ch)));

	msb_mask = msb_mask&ReadVal;
	SetVal = lsb_mask&SetVal;

	SetVal = SetVal|msb_mask;

	gpio_i2c_write2(jaguar1_i2c_addr2[motion_set->devnum], (0x02 + (0x07 * ch)), SetVal);
	printk("[DRV_Motion]ch(%d), readVal(%x), SetVal(%x)\n", ch, ReadVal, SetVal);
}
